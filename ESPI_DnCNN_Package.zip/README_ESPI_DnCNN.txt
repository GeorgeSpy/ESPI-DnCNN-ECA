ESPI DnCNN-Lite + ECA (CPU-safe) — Quick Start
=============================================
1) Copy both files to C:\ESPI_DnCNN\
   - espi_dncnn_lite_eca_full_cpu_safe_FIXED.py
2) Open 'Command Prompt' and run:
     cd C:\ESPI_DnCNN
     python -m venv venv
     venv\Scripts\activate
     python -m pip install --upgrade pip
     pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
     pip install numpy pillow tqdm onnx onnxruntime tensorboard
   (Optional for AMD iGPU inference)
     pip install onnxruntime-directml

3) Test one epoch (CPU):
     python espi_dncnn_lite_eca_full_cpu_safe_FIXED.py --device cpu --clean-root "C:\Users\Geiorge HTPC\Desktop\Mpouzoukia\W01_ESPI_90db-Averaged" --epochs 1 --batch-size 1 --tile 256 --overlap 32 --workers 0

4) Train longer:
     python espi_dncnn_lite_eca_full_cpu_safe_FIXED.py --device cpu --clean-root "C:\...\W01_ESPI_90db-Averaged" --output-dir "C:\...\outputs_W01" --epochs 50 --batch-size 2 --tile 256 --overlap 32 --workers 4

5) REAL evaluation (optional, requires matching folder structures):
     python espi_dncnn_lite_eca_full_cpu_safe_FIXED.py --device cpu --clean-root "C:\...\Averaged" --real-noisy-root "C:\...\SingleShot" --epochs 50 --batch-size 2 --tile 256 --overlap 32

6) Export ONNX:
     python espi_dncnn_lite_eca_full_cpu_safe_FIXED.py --device cpu --clean-root "C:\...\Averaged" --output-dir "C:\...\outputs_W01" --export-onnx "C:\...\dncnn_lite_eca.onnx"

Notes for Ryzen 5600G:
- Train on CPU. For faster inference use ONNX Runtime (CPU) or onnxruntime-directml (AMD iGPU).
- Keep tile=256 and overlap=32 to limit RAM use.
